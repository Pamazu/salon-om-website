# Manifesto

The brand idea on clay, **written in letter by letter**: each letter clears from a blur and rises into place (1.5s each, 20ms apart). Accent words are set in Light Italic, forest-deep. Two thin rings draw themselves behind the text and then breathe slowly.

- **Provide:** `text`, `accents` (exact words, punctuation included, e.g. `everything.`), `eyebrow`.
- Keep it to two or three sentences (under ~130 letters) so the writing finishes within about 4 seconds.
- Plays again each time the slide is reached.
