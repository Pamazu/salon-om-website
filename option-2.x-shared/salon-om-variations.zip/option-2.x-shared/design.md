# Design — Option 2.2, 2.3, 2.4

Builds on Option 2 (see `option-2-SAVED/design.md` for the full visual and motion system, which still applies). This file records what the variations add.

## Decisions

| # | Decision | Why |
| --- | --- | --- |
| V-1 | Funnel structure: hook (salon benefits) → pain or dream → five feature/benefit slides → Aveda → people → offer → bridge to coaching → call to action | Client: hook, tease, inform, then move people to act |
| V-2 | The element films stay but the copy speaks benefits, not elements | Client: "we don't have to be explicit about the elements" |
| V-3 | Two worlds in one page, Salon and Coaching, switched with a pill (header on desktop, docked at the bottom on phones). A circular veil in the target world's ground colour grows from the switch over 1.05s (`--io-strong`), the world changes beneath it, and the veil fades over 1.2s | Client: "a parallel world… similar style, not exactly the same" |
| V-4 | Coaching looks: **Dawn** (2.2, light linen and sage, italic headlines, light veils), **Clay** (2.3, warm daylight, arch frames), **Night** (2.4, violet-umber, lavender, smoke and water). Switchable in the tweak panel | Three directions to compare |
| V-5 | "Everything stops" (2.3): the hero film eases from 1× to stillness over 3.6s (sine ease-in-out) and pauses; the still frame keeps breathing (1 → 1.035, 14s) | Client: walking in feels transcendent, everything stops |
| V-6 | Walking in (2.3): the doorway photo slowly scales to 142% over 7s on arrival, as if you are stepping through | Same idea, continued |
| V-7 | New slide types: split (photo + copy, flip), facts (count-up numbers), team (portrait placeholders, never AI faces for Maggie), steps, bridge, doors, walk-in, rotating quotes, arch hero | Content needs |
| V-8 | Tweak panel on every variation; saving uses the artifact's own files (`tweaks.json` + `uploads/`), so the link stays shareable | Client: edit text, spacing, images and more ourselves |
| V-9 | OM in the manifesto stays upright (not italic) | Client |

## New photography (Magnific, Nano Banana 2)

Eight placeholder photos: scalp ritual, styling, botanicals, colour, rest, coaching room, meadow, arrival. People are shown from behind or as hands where possible; none stands in for Maggie.
